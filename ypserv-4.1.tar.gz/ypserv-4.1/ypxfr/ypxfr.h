
#ifndef __YPXFR_H__
#define __YPXFR_H__

extern bool_t ypxfr_xdr_ypresp_all(XDR *, ypresp_all *);

#endif
