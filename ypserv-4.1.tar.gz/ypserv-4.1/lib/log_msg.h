#ifndef __LOG_MSG_H__
#define __LOG_MSG_H__ 1

extern int debug_flag;

extern void log_msg (char *, ...);

#endif /* __LOG_MSG_H__ */

